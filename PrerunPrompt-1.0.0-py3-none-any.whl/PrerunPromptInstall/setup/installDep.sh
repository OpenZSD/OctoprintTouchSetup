#!/bin/sh

sudo apt-get install python3-tk
python3 -m pip install pysimplegui
